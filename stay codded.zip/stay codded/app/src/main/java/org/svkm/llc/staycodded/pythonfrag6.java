package org.svkm.llc.staycodded;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import org.svkm.llc.staycodded.databinding.Fragpy6Binding;
import org.svkm.llc.staycodded.pythonfrag1;
public class pythonfrag6 extends Fragment{
    private Fragpy6Binding fragbind;
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragpy6,container,false);
        return view;
    }
}

package org.svkm.llc.staycodded;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class clang extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public void finish(){
        super.finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
}

package org.svkm.llc.staycodded;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import org.svkm.llc.staycodded.databinding.Fragpy5Binding;
import org.svkm.llc.staycodded.pythonfrag1;
public class pythonfrag5 extends Fragment{
    private Fragpy5Binding fragbind;
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragpy5,container,false);
        return view;
    }
}

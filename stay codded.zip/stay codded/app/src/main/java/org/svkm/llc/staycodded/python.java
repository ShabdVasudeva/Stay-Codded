package org.svkm.llc.staycodded;

import android.content.Intent;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.text.Layout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import org.svkm.llc.staycodded.databinding.LayoutPythonBinding;
import org.svkm.llc.staycodded.python;
import org.svkm.llc.staycodded.pythonfrag1;
import org.svkm.llc.staycodded.pythonfrag2;

public class python extends AppCompatActivity {
    private LayoutPythonBinding pythonbin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pythonbin = LayoutPythonBinding.inflate(getLayoutInflater());
        setContentView(pythonbin.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(python.this, R.color.black));
        pythonbin.menupy.setOnClickListener(view->{
            Intent intent = new Intent(this, ViewProfile.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        pythonbin.intropy.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag1());
                });
        pythonbin.pyprogram.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag2());
                });
        pythonbin.pyvar.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag3());
                });
        pythonbin.pyin.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag4());
                });
        pythonbin.pydecision.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag5());
                });
        pythonbin.pyloop.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag6());
                });
        pythonbin.pyfunction.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag7());
                });
        pythonbin.pylist.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag9());
                });
        pythonbin.pytuple.setOnClickListener(
                view -> {
                    replaceFragment(new pythonfrag10());
                });
    }
    public void replaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frame,fragment).addToBackStack("name").commit();
    }
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}

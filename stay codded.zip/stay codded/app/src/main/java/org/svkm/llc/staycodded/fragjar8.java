package org.svkm.llc.staycodded;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import org.svkm.llc.staycodded.databinding.Fragjar8Binding;
import org.svkm.llc.staycodded.pythonfrag1;
public class fragjar8 extends Fragment{
    private Fragjar8Binding jarbind8;
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragjar8,container,false);
        return view;
    }
}

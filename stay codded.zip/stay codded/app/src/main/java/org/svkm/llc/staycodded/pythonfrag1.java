package org.svkm.llc.staycodded;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import org.svkm.llc.staycodded.databinding.FragpyBinding;
import org.svkm.llc.staycodded.pythonfrag1;
public class pythonfrag1 extends Fragment{
    private FragpyBinding fragbind;
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragpy,container,false);
        return view;
    }
}

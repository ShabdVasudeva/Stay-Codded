package org.svkm.llc.staycodded;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.FragmentManager;
import android.view.ViewGroup;
import org.svkm.llc.staycodded.databinding.Fragjar7Binding;
import org.svkm.llc.staycodded.pythonfrag1;
public class fragjar7 extends Fragment{
    private Fragjar7Binding jarbind7;
    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragjar7,container,false);
        return view;
    }
}

package org.svkm.llc.staycodded;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.fonts.Font;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import androidx.core.widget.NestedScrollView;
import javax.xml.transform.Source;
import org.svkm.llc.staycodded.clang;
import org.svkm.llc.staycodded.databinding.ActivityMainBinding;
import org.svkm.llc.staycodded.java;
import org.svkm.llc.staycodded.python;
import org.svkm.llc.staycodded.shell;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(binding.getRoot());
        binding.menu.setOnClickListener(
                view -> {
                    Intent intent = new Intent(this, ViewProfile.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding.quetionbut.setOnClickListener(
                view -> {
                    if (binding.question.getText().toString().contains("google")) {
                        Uri gog = Uri.parse("https://www.google.com/");
                        Intent google = new Intent(Intent.ACTION_VIEW, gog);
                        startActivity(google);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    } else if (binding.question.getText().toString().contains("code")) {
                        binding.ai.setText(
                                "Coding tests a variety of abilities. It hones problem-solving and analysis skills, such as finding errors and thinking logically. Further, coding often helps people develop teamwork and interpersonal skills since software and application projects are often cross-disciplinary and collaborative.");
                    } else if (binding.question.getText().toString().contains("debugging")) {
                        binding.ai.setText(
                                "Debugging is the process of finding and fixing errors or bugs in the source code of any software. When software does not work as expected, computer programmers study the code to determine why any errors occurred.");
                    } else if (binding.question.getText().toString().contains("compiler")
                            || binding.question.getText().toString().contains("Compiler")) {
                        binding.ai.setText(
                                "A compiler is a special program that translates a programming language's source code into machine code, bytecode or another programming language.");
                    } else if (binding.question.getText().toString().contains("application")
                            || binding.question.getText().toString().contains("Application")) {
                        binding.ai.setText("this application was written in java language.");

                    } else {
                        binding.ai.setText("sorry an error occured");
                    }
                });
        binding.python.setOnClickListener(
                view -> {
                    Intent python = new Intent(this, python.class);
                    startActivity(python);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding.java.setOnClickListener(
                view -> {
                    Intent java = new Intent(this, java.class);
                    startActivity(java);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding.sources.setOnClickListener(view ->{
            Toast.makeText(getApplicationContext(),"You Can Find the Source Codes of Java and python on our github profile",Toast.LENGTH_LONG).show();
                    Uri sourcego = Uri.parse("https://github.com/developer2207");
                    Intent gosogo = new Intent(Intent.ACTION_VIEW, sourcego);
                    startActivity(gosogo);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}

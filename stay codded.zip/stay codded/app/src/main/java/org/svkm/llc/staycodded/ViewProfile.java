package org.svkm.llc.staycodded;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import kotlinx.coroutines.flow.internal.AbortFlowException;
import org.svkm.llc.staycodded.databinding.ViewProfileBinding;
import org.svkm.llc.staycodded.python;

public class ViewProfile extends AppCompatActivity {
    private ViewProfileBinding binding2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding2 = ViewProfileBinding.inflate(getLayoutInflater());
        setContentView(binding2.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(ViewProfile.this, R.color.black));
        getWindow().setNavigationBarColor(ContextCompat.getColor(ViewProfile.this, R.color.black));
        binding2.about.setOnClickListener(
                view -> {
                    Intent activity = new Intent(this, AboutActivity.class);
                    startActivity(activity);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding2.pythongo.setOnClickListener(
                view -> {
                    Intent setting = new Intent(this, python.class);
                    startActivity(setting);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding2.javago.setOnClickListener(
                view -> {
                    Intent java = new Intent(this, java.class);
                    startActivity(java);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding2.sourcego.setOnClickListener(
                view -> {
                    Toast.makeText(getApplicationContext(),"You Can Find the Source Codes of Java and python on our github profile",Toast.LENGTH_LONG).show();
                    Uri source = Uri.parse("https://github.com/developer2207");
                    Intent goso = new Intent(Intent.ACTION_VIEW, source);
                    startActivity(goso);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
        binding2.donate.setOnClickListener(view ->{
            Toast.makeText(getApplicationContext(),"buy a cup of coffee for the developer through the qr code using the link...",Toast.LENGTH_LONG).show();
                Uri donate = Uri.parse("https://t.me/AndroidPortWorld/211");
                Intent godo = new Intent(Intent.ACTION_VIEW,donate);
                startActivity(godo);
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}

package org.svkm.llc.staycodded;

import android.os.Bundle;
import android.view.LayoutInflater;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.svkm.llc.staycodded.contributors;
import org.svkm.llc.staycodded.databinding.LayoutContributorsBinding;

public class contributors extends AppCompatActivity {
    private LayoutContributorsBinding bindcon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bindcon = LayoutContributorsBinding.inflate(getLayoutInflater());
        setContentView(bindcon.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(contributors.this,R.color.black));
        getWindow().setNavigationBarColor(ContextCompat.getColor(contributors.this,R.color.black));
    }
}

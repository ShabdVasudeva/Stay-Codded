package org.svkm.llc.staycodded;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.svkm.llc.staycodded.databinding.ActivityAboutBinding;
import org.svkm.llc.staycodded.databinding.ActivitySettingBinding;

public class SettingActivity extends AppCompatActivity {
    private ActivitySettingBinding bindings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bindings = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(bindings.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(SettingActivity.this,R.color.back));
    }
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
}

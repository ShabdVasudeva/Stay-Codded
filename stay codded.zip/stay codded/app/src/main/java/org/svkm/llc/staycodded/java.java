package org.svkm.llc.staycodded;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import org.svkm.llc.staycodded.databinding.LayoutJavaBinding;
import org.svkm.llc.staycodded.fragjar1;
import org.svkm.llc.staycodded.fragjar2;
import org.svkm.llc.staycodded.fragjar3;

public class java extends AppCompatActivity {
    private LayoutJavaBinding jarbind;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        jarbind = LayoutJavaBinding.inflate(getLayoutInflater());
        setContentView(jarbind.getRoot());
        jarbind.menujar.setOnClickListener(view->{
            Intent intent = new Intent(this, ViewProfile.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        jarbind.introjar.setOnClickListener(
                view -> {
                    javafrags(new fragjar1());
                });
        jarbind.jarprogram.setOnClickListener(
                view -> {
                    javafrags(new fragjar2());
                });
        jarbind.jarvar.setOnClickListener(
                view -> {
                    javafrags(new fragjar3());
                });
        jarbind.jarinput.setOnClickListener(
                view -> {
                    javafrags(new fragjar7());
                });
        jarbind.jarif.setOnClickListener(
                view -> {
                    javafrags(new fragjar4());
                });
        jarbind.jarloop.setOnClickListener(
                view -> {
                    javafrags(new fragjar5());
                });
        jarbind.jarclass.setOnClickListener(
                view -> {
                    javafrags(new fragjar8());
                });
        jarbind.jararray.setOnClickListener(
                view -> {
                    javafrags(new fragjar6());
                });
    }
    @Override
    public void finish(){
        super.finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
    public void javafrags(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frame2,fragment).addToBackStack("name").commit();
    }
}

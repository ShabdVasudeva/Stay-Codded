package org.svkm.llc.staycodded;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.svkm.llc.staycodded.contributors;
import org.svkm.llc.staycodded.databinding.ActivityAboutBinding;

public class AboutActivity extends AppCompatActivity {
    private ActivityAboutBinding binding3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding3 = ActivityAboutBinding.inflate(getLayoutInflater());
        setContentView(binding3.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(AboutActivity.this,R.color.black));
        binding3.contributors.setOnClickListener(view ->{
            Intent contribute = new Intent(this,contributors.class);
            startActivity(contribute);    
        });
        binding3.telegram.setOnClickListener(view ->{
            Uri uri = Uri.parse("https://t.me/AndroidPortWorld");
            Intent telegram = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(telegram);    
        });
        binding3.instagram.setOnClickListener(view ->{
            Uri uri2 = Uri.parse("https://www.instagram.com/v_shabd_developer?igsh=MWJrZW9xYXdsd2VibA==");
            Intent instagram = new Intent(Intent.ACTION_VIEW,uri2);
            startActivity(instagram);     
        });
    }
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
    
}
